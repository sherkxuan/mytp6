<?php
// 这是系统自动生成的middleware定义文件
return [
   //\think\trace\TraceDebug::class,
    //调用接口中间件，用于权限验证及统计
    \app\middleware\ApiCount::class
];
